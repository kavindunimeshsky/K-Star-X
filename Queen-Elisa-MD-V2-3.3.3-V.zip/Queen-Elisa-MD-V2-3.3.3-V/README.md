
<p align="center"> 
<u>♥️ ᴀɴ ᴡʜᴀᴛsᴀᴘᴘ ᴜsᴇʀ ʙᴏᴛ ʙʏ ᴍʀ ɴɪᴍᴀ ♥️</u>
</p>
<p align="center">
<img src="https://telegra.ph/file/ffdb2c3cfba2016eb4e17.jpg" width="300" height="300"/>
</p>
<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=Queen+Elisa+Whatsapp+Bot" alt="">
</p>
<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-Mrnima-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/darkmakerofc?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/AlipBot?color=green&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/darkmakerofc/Queen-Elisa-MD-V2?color=white&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/network/members"><img title="Forks" src="https://img.shields.io/github/forks/darkmakerofc/Queen-Elisa-MD-V2?color=yellow&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/darkmakerofc/Queen-Elisa-MD-V2?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/"><img title="Size" src="https://img.shields.io/github/repo-size/AlipBot/Api-Alpis?style=flat-square&color=darkred"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/%2Fhit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2304FF00&title=hits&edge_flat=false"/></a>
<a href="https://github.com/DarkMakerofc/Queen-Elisa-Md-V2/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;
</p>

# 

### Please Give One Star ✨ & [follow for me notify my updates](https://github.com/DarkMakerofc)
<b>Version --> 3.3.5</b>
# 
Queen elisa whatsapp bot is,

      Queen elisa whatsapp bot is an easy to use whatsapp robot thkx xeon.   |  Queen elisa whatsapp bot යනු ඔබට පහසුවෙන් බාවිතකර හැකි whatsapp robo වරයෙකි.

# 
# 
* 𝗙𝗢𝗥𝗞 𝗡𝗢𝗪

<p align="left">
<a href="https://github.com/DarkMakerofc/Queen-Elisa-MD-V2/fork"><img align="center" src="https://telegra.ph/file/3514997e86c4bb12d8f67.png" alt="Fork and deploy" height="35" width="155" /></a>

# 

* [`1️⃣ 𝗦𝗖𝗔𝗡 𝗤𝗥 𝗖𝗢𝗗𝗘`](https://QUEEN-ELISA-MD-V3.mrnima.repl.co)
* [`2️⃣ 𝗦𝗖𝗔𝗡 𝗤𝗥 𝗖𝗢𝗗𝗘`](https://QUEEN-ELISA-MD-V3-2nd-Qr-Scaner.mrnima.repl.co/)
* [`3️⃣ 𝗦𝗖𝗔𝗡 𝗤𝗥 𝗖𝗢𝗗𝗘`](https://replit.com/@MRNima/Queen-V230#index.js)

      ℹ️ if there any error please infrom it support group.  | මෙහිදී යම් ගැටලුවක් ඇති උවහොත් සහය සමූහය වෙත සම්බන්ධ වන්න.
# 

<details>
<summary> ℹ️ Deploy Now ℹ️( Click to get deploy methods ) </summary>


[`Deploy on Railway`](https://railway.app?referralCode=jDDNQq)

[`Deploy on Koyeb`](https://app.koyeb.com/)

[`Deploy on Mogenius`](https://studio.mogenius.com/)

[`Deploy on heroku`](https://heroku.com/)

[`Deploy on Replit`](https://replit.com)

[`Deploy on Uffizzi`](https://www.uffizzi.com/)
<p>
</details>

# 

## [`WATCH YOUTUBE VIDEOS`](youtube.com/MRNIMAOFC)

# 
# 
# 
#
+ DEPLOY STEPS
# 
1. Fork This Repository 
2. Update [settings.js]()
3. Uplode session.json file
4. Make acount on your host
5. Connect Your Repository to your web host site
6. [ Watch Video]()
# 
# 
### [ DEPLY ON TERMUX ]
 ```   
apt update
apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/DarkMakerofc/Queen-Elisa-Md-V2
cd Queen-Elisa-Md-V2
npm install
npm start
```
<details>
<summary>✅ New Updates</summary>


## 🆕 New additions 🆕

➕ New Tiktok Downloader ( Wm / No Wm / audio )

➕ New Fb Downloader (Add list message : SD / HD )

➕ OpenAi ( ChatGPT )

➕ True Caller ( Mobile Number details fetcher )

➕ Add New Tag Option ( tag any messages in groups : video / audio / document / stickers / images )

➕ Add New Bot Status Fetcher ( Runtime / ramusage / platform / speed etc )

➕ New Movie Details Fetcher ( Not a Downloader )

➕ Block any word on image downloader ( You must add words )

➕ User Status Downloader ( Download status video or image using bot )

➕ Reqested status sender ( Requested status send for requester )

➕ Add TagAdmin 

➕ Only Prefix mod ( can turn off /  on it )

➕ Uplode 100MB + Videos (  if you use this you must have paid host sever )


## 🛠️  FIX  🛠️

✔️ Image downloader

✔️ Google search

✔️ Mediafire Downloader

✔️ Ssweb 

✔️ Pemoji 

✔️ Sticker maker


✔️ to image / Gif / mp4 / mp3 / voice Converter

✔️ Add command error

✔️ Apk Downloader

✔️ Text to voice converter

✔️ Hide tag / tag


<p>
</details>
<details>
<summary>ℹ️ How To Update </summary>
<p>
</details>
<details>
<summary>🌐 Support For Deploy </summary>
<p>
</details>
THANAKS FOR USNING QUEEN ELISA 💃💖

* [🧑‍💻 Join Queen Elisa Support Group 🧑‍💻](https://t.me/+Fc2vyKYBjFk3ZWZl)

* [🦄 Join Public Group 🦄](https://chat.whatsapp.com/BbIpvkRD4qP6xKckb8cpT0)

     
       ⚠️ We are not responsible for any inconvenience caused by your mistakes!   | ඔබගේ අත්වැරදීම් නිසා සිදුවන අපහසුතාවයන් සඳහා අප වගකිවයනු නොලැබේ !


<h1>💗</h1> 
<b>Thanks For</b> -

 [xeon](github.com/zimbot) for script , [thashi 💖]() for Voice ,[slrealtech]() , [darkalpha]() , [sanuwa]() and [isuru]() thanks for helps 💖
